#!/usr/bin/env python
# '''
#     This node would transfer the glove data '/cybertouch/raw/joint_states' through panda datafram
#   make the file useful for machine learning process.
    
# '''

from std_msgs.msg import String
import serial
import rospy
from sensor_msgs.msg import JointState
import sys
import numpy as np
import pandas as pd
import csv

Dataf = pd.DataFrame({
    "ThumbRotate":[0.],"ThumbMPJ":[0.],"ThumbIJ":[0.],"ThumbAb":[0.],
    "IndexMPJ":[0.],"IndexIJ":[0.],"MiddleMPJ":[0.],"MiddleIJ":[0.],"MiddleIndexAb":[0.],
    "RingMPJ":[0.],"RingIJ":[0.],"RingMiddleAb":[0.],
    "PinkieMPJ":[0.],"PinkieIJ":[0.],"PinkieRingAb":[0.]
    })
   
# three sensor : ("G_PalmArch")("G_WristPitch")("G_WristYaw") not using.

def add_row(df, row):
    df.loc[-1] = row
    df.index = df.index + 1

    return df


def Cybertrans(msg):

    #Finger position:
    vGlove = np.array([msg.position[1], msg.position[2], msg.position[3],
                    msg.position[4], msg.position[5], msg.position[6], 
                    msg.position[7], msg.position[8], msg.position[9],
                    msg.position[10], msg.position[11], msg.position[12],
                    msg.position[13], msg.position[14], msg.position[15]])
   
    # Einstein summation convention: minus distance:
    #      n = np.sqrt(np.einsum('ij,ij->i', a_min_b, a_min_b))
    
    

    add_row(Dataf,[vGlove[0],vGlove[1], vGlove[2], vGlove[3],vGlove[4], vGlove[5], vGlove[6],vGlove[7], vGlove[8], vGlove[9],vGlove[10], vGlove[11], vGlove[12],vGlove[13], vGlove[14]])
    Dataf.sort_index()
    
    print Dataf
    Dataf.to_csv("/home/xander/Hand_nws/src/cybertouch/Data/object1_array.csv")


if __name__ == '__main__':

    rospy.init_node('Thumb_trans',anonymous=True)

    #subscribe to a topic using rospy.Subscriber class
    trans_sub = rospy.Subscriber('/cybertouch/raw/joint_states',JointState, Cybertrans)
    
    rospy.spin()
#!/usr/bin/env python
# '''
#     This node would transfer the /leapnode/hand_infoarray to calculate the parameters for 
#         supervising the synergy of ada_hand.
    
# '''

from std_msgs.msg import String
import serial
import rospy
from sensor_msgs.msg import JointState
import sys
import numpy as np
import pandas as pd
import csv

Dataf = pd.DataFrame({"D1_3x":[0.],"D1_3y":[0.],"D1_3z":[0.]})

def add_row(df, row):
    df.loc[-1] = row
    df.index = df.index + 1

    return df


def LeapCalculator(marker_msg):

    #Thumb finger tip
    v1_3 = np.array([marker_msg.position[6], marker_msg.position[7], marker_msg.position[8]])
   
    # Einstein summation convention: minus distance:
    #      n = np.sqrt(np.einsum('ij,ij->i', a_min_b, a_min_b))
    
    

    add_row(Dataf,[v1_3[0],v1_3[1], v1_3[2]])
    Dataf.sort_index()
    
    print Dataf
    Dataf.to_csv("/home/xander/Hand_nws/src/leapnode/Data/Thumbtip_array.csv")



if __name__ == '__main__':

    rospy.init_node('Thumb_trans',anonymous=True)

    #subscribe to a topic using rospy.Subscriber class
    trans_sub = rospy.Subscriber('/leapnode/handinfo_array',JointState, LeapCalculator)
    
    rospy.spin()
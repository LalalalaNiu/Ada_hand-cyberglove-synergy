#!/usr/bin/env python
# '''
#     This node would transfer the /leapnode/hand_infoarray to calculate the parameters for 
#         supervising the synergy of ada_hand.
    
# '''

from std_msgs.msg import String
import serial
import rospy
from sensor_msgs.msg import JointState
import sys
import numpy as np
import pandas as pd

import csv

Dataf = pd.DataFrame({"D1_3x":[0.],"D1_3y":[0.],"D1_3z":[0.]})

def add_row(df, row):
    df.loc[-1] = row
    df.index = df.index + 1

    return df


def LeapCalculator(marker_msg):

    i = 0
    
    Leap_pub = rospy.Publisher('/leaptrans/dataframe', String, queue_size=2)
#pack 1000 times data into one dataframe
  
    # aim the position of the finger in the dataflow.
    leap_msg =str(marker_msg.name)[4] #the first capital letter.

    # joint 3(fingertip) and joint 1(middle joint is the most importtant for the finger).
    # build the vector for the point. v1-5 from thumb to pinky.
    #finger tip
    v1_3 = np.array([marker_msg.position[6], marker_msg.position[7], marker_msg.position[8]])
    v2_3 = np.array([marker_msg.position[15], marker_msg.position[16], marker_msg.position[17]])
    v3_3 = np.array([marker_msg.position[24], marker_msg.position[25], marker_msg.position[26]])
    v4_3 = np.array([marker_msg.position[33], marker_msg.position[34], marker_msg.position[35]])
    v5_3 = np.array([marker_msg.position[42], marker_msg.position[43], marker_msg.position[44]])

    #finger mid-joint
    v1_1 = np.array([marker_msg.position[0], marker_msg.position[1], marker_msg.position[2]])
    v2_1 = np.array([marker_msg.position[9], marker_msg.position[10], marker_msg.position[11]])
    v3_1 = np.array([marker_msg.position[18], marker_msg.position[19], marker_msg.position[20]])
    v4_1 = np.array([marker_msg.position[27], marker_msg.position[28], marker_msg.position[29]])
    v5_1 = np.array([marker_msg.position[36], marker_msg.position[37], marker_msg.position[38]])

    vP = np.array([marker_msg.position[45], marker_msg.position[46], marker_msg.position[47]])
    # Distance From fingertip to palm;
    # Einstein summation convention: minus distance:
    #      n = np.sqrt(np.einsum('ij,ij->i', a_min_b, a_min_b))
    
    D1_3 = v1_3 - vP
    D2_3 = v2_3 - vP
    D3_3 = v3_3 - vP
    D4_3 = v4_3 - vP
    D5_3 = v5_3 - vP
    
    D1_1 = v1_1 - vP
    D2_1 = v2_1 - vP    
    D3_1 = v3_1 - vP
    D4_1 = v4_1 - vP
    D5_1 = v5_1 - vP
    #special distance: Thumb finger tip to index & middle (Ring???).
    D12 = D2_3 - D1_3
    D13 = D3_3 - D1_3

    #define the dataframe.
    
    
    # Dataf1 = pd.DataFrame({"D1_3x":D1_3[0],"D1_3y":D1_3[1],"D1_3z":D1_3[2]})

    add_row(Dataf,[D1_3[0],D1_3[1], D1_3[2]])
    Dataf.sort_index()
    print D1_3[0]
    
    print Dataf
    Dataf.to_csv("/home/xander/Hand_nws/src/leapnode/Data/df.csv")
    # realative positon of the joint and the palm center as parameter. Dist1~5 from thumb to pinky.

    
    # dist1 = marker_msg.position[1]



    
    
    
    # TODO: Calibrate the values to be published in the topic /calibrated/joint_states or 
    #  separate the data to what we only use: finger (thumb 2) and the wrist.
    
    # jointstate_raw_msg.position[1] 
    # jointstate_raw_msg.position[2]
    # jointstate_raw_msg.position[5] 
    # jointstate_raw_msg.position[7]
    # jointstate_raw_msg.position[10]
    # jointstate_raw_msg.position[13]

    #inherit the Publisher pub_name
    
         #leap_msg = Leapmarkers

    

    #pubulish the actuator control signal:
    
    # Leap_pub.publish(int(D1_3))



if __name__ == '__main__':

    rospy.init_node('leaptrans',anonymous=True)

    #subscribe to a topic using rospy.Subscriber class
    trans_sub = rospy.Subscriber('/leapnode/handinfo_array',JointState, LeapCalculator)
    
    rospy.spin()
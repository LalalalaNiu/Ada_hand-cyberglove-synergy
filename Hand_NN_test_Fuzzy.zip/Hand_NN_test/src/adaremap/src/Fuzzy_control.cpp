#include <fl/Headers.h>
#include <math.h>
#include <signal.h>
#include "ros/ros.h"
#include "std_msgs/Float64.h"


using namespace fl;

Engine *finger1 = new Engine("Finger1_feedback_controller");
InputVariable *pressure1 = new InputVariable;
InputVariable *microvibrations1 = new InputVariable;
OutputVariable *status1 = new OutputVariable;
OutputVariable *stability1 = new OutputVariable;

Engine *finger2 = new Engine("Finger2_feedback_controller");
InputVariable *pressure2 = new InputVariable;
InputVariable *microvibrations2 = new InputVariable;
OutputVariable *status2 = new OutputVariable;
OutputVariable *stability2 = new OutputVariable;

Engine *grasp = new Engine("Grasp_controller");
InputVariable* Finger1Status = new InputVariable;
InputVariable* Finger1Stability = new InputVariable;
InputVariable* Finger2Status = new InputVariable;
InputVariable* Finger2Stability = new InputVariable;
OutputVariable* Finger1Action = new OutputVariable;
OutputVariable* Finger2Action = new OutputVariable;

void fuzzy_finger1_setup(){
	finger1->setName("Finger1_feedback_controller");
	finger1->setDescription("");

	pressure1->setName("Pressure");
	pressure1->setDescription("");
	pressure1->setEnabled(true);
	pressure1->setRange(0.000, 1.000);
	pressure1->setLockValueInRange(false);
//	pressure1->addTerm(new Trapezoid("Nopressure", 0.000, 0.189, 0.252, 0.294));
//	pressure1->addTerm(new Trapezoid("Lowpressure", 0.252, 0.294, 0.421, 0.505));
//	pressure1->addTerm(new Trapezoid("Normalpressure", 0.421, 0.505, 0.631, 0.736));
//	pressure1->addTerm(new Trapezoid("Highpressure", 0.631, 0.736, 0.842, 1.000));
	pressure1->addTerm(new Trapezoid("Nopressure", 0.000, 0.050, 0.100, 0.150));
	pressure1->addTerm(new Trapezoid("Lowpressure", 0.100, 0.150, 0.350, 0.400));
	pressure1->addTerm(new Trapezoid("Normalpressure", 0.350, 0.400, 0.650, 0.700));
	pressure1->addTerm(new Trapezoid("Highpressure", 0.650, 0.700, 0.950, 1.000));
	finger1->addInputVariable(pressure1);

	microvibrations1->setName("Microvibrations");
	microvibrations1->setDescription("");
	microvibrations1->setEnabled(true);
	microvibrations1->setRange(0.000, 1.000);
	microvibrations1->setLockValueInRange(false);
//	microvibrations1->addTerm(new Trapezoid("Low", 0.000, 0.285, 0.392, 0.642));
//	microvibrations1->addTerm(new Trapezoid("High", 0.392, 0.642, 0.714, 1.000));
	microvibrations1->addTerm(new Ramp("Low", 0.600, 0.300));
	microvibrations1->addTerm(new Ramp("High", 0.400, 0.700));
	finger1->addInputVariable(microvibrations1);

	status1->setName("Status");
	status1->setDescription("");
	status1->setEnabled(true);
	status1->setRange(0.000, 1.000);
	status1->setLockValueInRange(false);
	status1->setAggregation(new Maximum);
	status1->setDefuzzifier(new Centroid(100));
	status1->setDefaultValue(fl::nan);
	status1->setLockPreviousValue(false);
	status1->addTerm(new Trapezoid("Notouch", 0.000, 0.167, 0.208, 0.375));
	status1->addTerm(new Trapezoid("Touching", 0.208, 0.375, 0.416, 0.583));
	status1->addTerm(new Trapezoid("Holding", 0.416, 0.583, 0.625, 0.791));
	status1->addTerm(new Trapezoid("Pushing", 0.625, 0.791, 0.833, 1.000));
	finger1->addOutputVariable(status1);

	stability1->setName("Stability");
	stability1->setDescription("");
	stability1->setEnabled(true);
	stability1->setRange(0.000, 1.000);
	stability1->setLockValueInRange(false);
	stability1->setAggregation(new Maximum);
	stability1->setDefuzzifier(new Centroid(100));
	stability1->setDefaultValue(fl::nan);
	stability1->setLockPreviousValue(false);
	stability1->addTerm(new Trapezoid("Notstable", 0.000, 0.285, 0.357, 0.535));
	stability1->addTerm(new Trapezoid("Stable", 0.357, 0.642, 0.714, 1.000));
	finger1->addOutputVariable(stability1);

	RuleBlock* ruleBlock1 = new RuleBlock;
	ruleBlock1->setName("");
	ruleBlock1->setDescription("");
	ruleBlock1->setEnabled(true);
	ruleBlock1->setConjunction(new AlgebraicProduct);
	ruleBlock1->setDisjunction(new AlgebraicSum);
	ruleBlock1->setImplication(new AlgebraicProduct);
	ruleBlock1->setActivation(new General);
	ruleBlock1->addRule(Rule::parse("if Pressure is Nopressure then Status is Notouch", finger1));
	ruleBlock1->addRule(Rule::parse("if Pressure is Lowpressure then Status is Touching", finger1));
	ruleBlock1->addRule(Rule::parse("if Pressure is Normalpressure and Microvibrations is Low then Status is Holding", finger1));
	ruleBlock1->addRule(Rule::parse("if Pressure is Highpressure then Status is Pushing", finger1));
	finger1->addRuleBlock(ruleBlock1);

	RuleBlock* ruleBlock2 = new RuleBlock;
	ruleBlock2->setName("");
	ruleBlock2->setDescription("");
	ruleBlock2->setEnabled(true);
	ruleBlock2->setConjunction(new AlgebraicProduct);
	ruleBlock2->setDisjunction(new AlgebraicSum);
	ruleBlock2->setImplication(new AlgebraicProduct);
	ruleBlock2->setActivation(new General);
	ruleBlock2->addRule(Rule::parse("if Microvibrations is Low then Stability is Stable", finger1));
	ruleBlock2->addRule(Rule::parse("if Microvibrations is High then Stability is Notstable", finger1));
	finger1->addRuleBlock(ruleBlock2);

	std::string status;
	if (not finger1->isReady(&status))
        throw Exception("Engine not ready. "
                        "The following errors were encountered:\n" + status, FL_AT);
}

void fuzzy_finger2_setup(){
	finger2->setName("Finger2_feedback_controller");
	finger2->setDescription("");

	pressure2->setName("Pressure");
	pressure2->setDescription("");
	pressure2->setEnabled(true);
	pressure2->setRange(0.000, 1.000);
	pressure2->setLockValueInRange(false);
	/*pressure2->addTerm(new Trapezoid("Nopressure", 0.000, 0.189, 0.252, 0.294));
	pressure2->addTerm(new Trapezoid("Lowpressure", 0.252, 0.294, 0.421, 0.505));
	pressure2->addTerm(new Trapezoid("Normalpressure", 0.421, 0.505, 0.631, 0.736));
	pressure2->addTerm(new Trapezoid("Highpressure", 0.631, 0.736, 0.842, 1.000));*/
	pressure2->addTerm(new Trapezoid("Nopressure", 0.000, 0.050, 0.100, 0.150));
	pressure2->addTerm(new Trapezoid("Lowpressure", 0.100, 0.150, 0.350, 0.400));
	pressure2->addTerm(new Trapezoid("Normalpressure", 0.350, 0.400, 0.650, 0.700));
	pressure2->addTerm(new Trapezoid("Highpressure", 0.650, 0.700, 0.950, 1.000));
	finger2->addInputVariable(pressure2);

	microvibrations2->setName("Microvibrations");
	microvibrations2->setDescription("");
	microvibrations2->setEnabled(true);
	microvibrations2->setRange(0.000, 1.000);
	microvibrations2->setLockValueInRange(false);
//	microvibrations2->addTerm(new Trapezoid("Low", 0.000, 0.285, 0.392, 0.642));
//	microvibrations2->addTerm(new Trapezoid("High", 0.392, 0.642, 0.714, 1.000));
	microvibrations2->addTerm(new Ramp("Low", 0.600, 0.300));
	microvibrations2->addTerm(new Ramp("High", 0.400, 0.700));
	finger2->addInputVariable(microvibrations2);

	status2->setName("Status");
	status2->setDescription("");
	status2->setEnabled(true);
	status2->setRange(0.000, 1.000);
	status2->setLockValueInRange(false);
	status2->setAggregation(new Maximum);
	status2->setDefuzzifier(new Centroid(100));
	status2->setDefaultValue(fl::nan);
	status2->setLockPreviousValue(false);
	status2->addTerm(new Trapezoid("Notouch", 0.000, 0.167, 0.208, 0.375));
	status2->addTerm(new Trapezoid("Touching", 0.208, 0.375, 0.416, 0.583));
	status2->addTerm(new Trapezoid("Holding", 0.416, 0.583, 0.625, 0.791));
	status2->addTerm(new Trapezoid("Pushing", 0.625, 0.791, 0.833, 1.000));
	finger2->addOutputVariable(status2);

	stability2->setName("Stability");
	stability2->setDescription("");
	stability2->setEnabled(true);
	stability2->setRange(0.000, 1.000);
	stability2->setLockValueInRange(false);
	stability2->setAggregation(new Maximum);
	stability2->setDefuzzifier(new Centroid(100));
	stability2->setDefaultValue(fl::nan);
	stability2->setLockPreviousValue(false);
	stability2->addTerm(new Trapezoid("Notstable", 0.000, 0.285, 0.357, 0.535));
	stability2->addTerm(new Trapezoid("Stable", 0.357, 0.642, 0.714, 1.000));
	finger2->addOutputVariable(stability2);

	RuleBlock* ruleBlock1 = new RuleBlock;
	ruleBlock1->setName("");
	ruleBlock1->setDescription("");
	ruleBlock1->setEnabled(true);
	ruleBlock1->setConjunction(new AlgebraicProduct);
	ruleBlock1->setDisjunction(new AlgebraicSum);
	ruleBlock1->setImplication(new AlgebraicProduct);
	ruleBlock1->setActivation(new General);
	ruleBlock1->addRule(Rule::parse("if Pressure is Nopressure then Status is Notouch", finger2));
	ruleBlock1->addRule(Rule::parse("if Pressure is Lowpressure then Status is Touching", finger2));
	ruleBlock1->addRule(Rule::parse("if Pressure is Normalpressure and Microvibrations is Low then Status is Holding", finger2));
	ruleBlock1->addRule(Rule::parse("if Pressure is Highpressure then Status is Pushing", finger2));
	finger2->addRuleBlock(ruleBlock1);

	RuleBlock* ruleBlock2 = new RuleBlock;
	ruleBlock2->setName("");
	ruleBlock2->setDescription("");
	ruleBlock2->setEnabled(true);
	ruleBlock2->setConjunction(new AlgebraicProduct);
	ruleBlock2->setDisjunction(new AlgebraicSum);
	ruleBlock2->setImplication(new AlgebraicProduct);
	ruleBlock2->setActivation(new General);
	ruleBlock2->addRule(Rule::parse("if Microvibrations is Low then Stability is Stable", finger2));
	ruleBlock2->addRule(Rule::parse("if Microvibrations is High then Stability is Notstable", finger2));
	finger2->addRuleBlock(ruleBlock2);

	std::string status;
	if (not finger2->isReady(&status))
        throw Exception("Engine not ready. "
                        "The following errors were encountered:\n" + status, FL_AT);
}
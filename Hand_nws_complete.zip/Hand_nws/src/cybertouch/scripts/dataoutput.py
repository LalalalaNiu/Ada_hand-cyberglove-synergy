#!/usr/bin/env python
# '''
#     This node would transfer the glove data '/cybertouch/raw/joint_states' through panda datafram
#   make the file useful for machine learning process.
    
# '''

import serial
import rospy
import sys
import numpy as np
from std_msgs.msg import Int16MultiArray
from std_msgs.msg import Float32MultiArray
from std_msgs.msg import String
import random


global FingerData 
FingerData = Float32MultiArray()
FingerData.data = np.zeros(10)


def A_pose(act_data):
    
    for a in range(1,6):
        FingerData.data[(2*a)-2] =  act_data.data[a-1]



def S_pose(servo_data):

    S_data1= [0.0,0.0,0.0,0.0]
    for i in range (1,5):
        S_data1[i-1] = float(servo_data.data[i-1])

    S_data1.append(servo_data.data[3])
    
    S_data2 = np.array(S_data1)
    S_data2 = (S_data2)/180


    
    for a in range (1,6):
        FingerData.data[(2*a)-1] = S_data2[a-1]
       
    print(FingerData)
    # Einstein summation convention: minus distance:
    #      n = np.sqrt(np.einsum('ij,ij->i', a_min_b, a_min_b))

    
    pub.publish(FingerData)



    
if __name__ == '__main__':

    rospy.init_node('dataout',anonymous=True)
    pub = rospy.Publisher('/data_out', Float32MultiArray, queue_size=2)

    try:
        
        Norm_act = rospy.Subscriber('/position', Float32MultiArray, A_pose)
        Norm_servo = rospy.Subscriber('/servo', Int16MultiArray, S_pose)
       
        
    except ROSException:
        pass
#subscribe to a topic using rospy.Subscriber class
    
    
    rospy.spin()
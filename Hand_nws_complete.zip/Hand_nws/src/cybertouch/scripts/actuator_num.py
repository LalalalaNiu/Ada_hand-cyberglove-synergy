#!/usr/bin/env python

from std_msgs.msg import String
import rospy
from std_msgs.msg import Int16MultiArray
import sys



def num(act_msgs):
    # #pubulish the actuator control signal:
    

    Act = str(act_msgs.data)
   
    a1 = int(Act[6:9],10)
    a2 = int(Act[12:15],10)
    a3 = int(Act[18:21],10)
    a4 = int(Act[24:27],10)
    a5 = int(Act[30:33],10)
    a6 = int(Act[36:39],10)
    array = [a1,a2,a3,a4,a5,a6]
    num_msg = Int16MultiArray(data = array)
    num_pub.publish(num_msg)


    
if __name__ == '__main__':

    rospy.init_node('actuator',anonymous=True)
    #subscribe to a topic using rospy.Subscriber class
    
    num_pub = rospy.Publisher('/cybertouch/actuator_num', Int16MultiArray, queue_size=2)
   
    try:
        num_sub = rospy.Subscriber('/cybertouch/actuator_states', String, num)
        
    except ROSException:
        pass

    
    rospy.spin()
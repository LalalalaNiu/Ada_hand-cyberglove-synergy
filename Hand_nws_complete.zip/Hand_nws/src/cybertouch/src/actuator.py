#!/usr/bin/env python
'''
    This node would only use the FSR sensor data to actuate the actuators.
    (would realated on the rosbot hand feed back)
'''

from std_msgs.msg import String
import serial
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Int16MultiArray

import random
import sys



a1 = 0
a2 = 0
a3 = 0
a4 = 0
a5 = 0
a6 = 0



def actuator(Fsr_msgs):
    # set the actuator condition: 0~255, 64 start to vibrate
    
    actuator_msg = String
   
    num = [0, 255]

#  set the vibration power for each actuator. a1-a5 is from thumb to the pinky, And a6 is for the plam.
    #inherit the Publisher name

    # actuator_msg = String
    
#    ###  The acuator vibrate start at 64 up to 255.  ###

    if 20<= Fsr_msgs.data[1] <= 820:
        a1 = (Fsr_msgs.data[1]-20)/4.21 + 65
        a1 = int(a1)
        
    elif Fsr_msgs.data[1] > 820:
        a1 = random.choice(num)
    else:
        a1 =0    
        
    if 10 <= Fsr_msgs.data[2] <= 810:
        a2 = (Fsr_msgs.data[2]-10)/4.21 + 65
        a2 = int(a2)
       
    elif Fsr_msgs.data[2] > 810:
        a2 = random.choice(num)
    else:
        a2 =0
    if 10 <= Fsr_msgs.data[3] <= 810:
        a3 = (Fsr_msgs.data[3]-10)/4.21 + 65
        a3 = int(a3)
        
    elif Fsr_msgs.data[3] > 810:
        a3 = random.choice(num)
    else:
        a3 =0
 
    if 10 <= Fsr_msgs.data[4] <= 810:
        a4 = (Fsr_msgs.data[4]-10)/4.21 + 65
        a4 = int(a4)
       
    elif Fsr_msgs.data[4] > 810:
        a4 = random.choice(num)
    else:
        a4 =0
    if 10 <= Fsr_msgs.data[5] <= 810:
        a5 = (Fsr_msgs.data[5]-10)/4.21 + 65
        a5 = int(a5)
       
    elif Fsr_msgs.data[5] > 810:
        a5 = random.choice(num)
    else:
        a5 =0

    if 10 <= Fsr_msgs.data[0] <= 810:
        a6 = (Fsr_msgs.data[0]-10)/4.21 + 65
        a6 = int(a6)
        
    elif Fsr_msgs.data[1] > 810:
        a6 = random.choice(num)
    else:
        a6 =0
    a1 = ' ' + "%03d" % a1
    a2 = ' ' + "%03d" % a2
    a3 = ' ' + "%03d" % a3
    a4 = ' ' + "%03d" % a4
    a5 = ' ' + "%03d" % a5
    a6 = ' ' + "%03d" % a6
    

    actuator_msg = 'a 6' + ' 0' + a1 + ' 1' + a2 + ' 2' + a3 + ' 3' + a4 + ' 4' + a5 + ' 5' + a6 + ' \r'
    # print actuator_msg
    #pubulish the actuator control signal:
    actuator_pub.publish(actuator_msg)
   
   


    
if __name__ == '__main__':

    rospy.init_node('actuator',anonymous=True)
    #subscribe to a topic using rospy.Subscriber class
    
    actuator_pub = rospy.Publisher('/cybertouch/actuator_states', String, queue_size=2)
   

    try:
        actuator_sub = rospy.Subscriber('/Fsr/sensor_msgs', Int16MultiArray, actuator)
        
    except ROSException:
        pass

    
    rospy.spin()
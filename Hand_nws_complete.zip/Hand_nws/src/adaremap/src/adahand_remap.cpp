/* 
* This node remaps the data from cyberglove to positions sent to Ada hand  
* It gets the cyberglove's data by subscribing the topic "/cybertouch/raw/joint_states"
* It calculates the finger positions through weighted average of the finger joints values
* It publishes the finger positions in the topic '/position'   '/servo'

* For better results:
* Thumb and Pinkie positions - Weighted average
* Other fingers positions - Arithmetic mean
*/

#include <ros/ros.h>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Int16MultiArray.h>
#include <sensor_msgs/JointState.h>
#include <algorithm>

enum Fingers {Thumb, Index, Middle, Ring, Pinkie};

// each finger would be seperate into two parameter. The joints that will be used is here.
const std::vector<std::string> ThumbJ = {"G_ThumbRotate", "G_ThumbMPJ","G_ThumbIJ"};
const std::vector<std::string> IndexJ = {"G_IndexMPJ","G_IndexIJ"}; 
const std::vector<std::string> MiddleJ = {"G_MiddleMPJ","G_MiddleIJ"};
const std::vector<std::string> RingJ = {"G_RingMPJ","G_RingIJ"};
const std::vector<std::string> PinkieJ = {"G_PinkieMPJ","G_PinkieIJ"};
// const std::vector<std::string> WristJoints = {"G_WristPitch", "G_WristYaw"};

// Min and max values will be used to calibrate the glove
// Set the min and max values by comparing the current values received form the glove to the lastest min and max
double minValueThumbJoints[]  = {1.0, 1.0, 1.0};
double minValueIndexJoints[]  = {1.0, 1.0};
double minValueMiddleJoints[] = {1.0, 1.0};
double minValueRingJoints[]   = {1.0, 1.0};
double minValuePinkieJoints[] = {1.0, 1.0};
//double minValueWristJoints[]  = {1.0, 1.0};

double maxValueThumbJoints[]  = {0, 0, 0};
double maxValueIndexJoints[]  = {0, 0};
double maxValueMiddleJoints[] = {0, 0};
double maxValueRingJoints[]   = {0, 0};
double maxValuePinkieJoints[] = {0, 0};
//double maxValueWristJoints[]  = {0, 0};


// Wheight of each joint to calculate the position to be sent
// Sum of the wheights has to be 1
double WThumb[2]  = {0.65, 0.35}; // Weighted average for thumb position
// Convert the joints' values in the range [0;1] 
double divr = 0; // divr = max - min
double divr_aux = 0;
double min = 0;
double max = 0;
double jointValue1 = 0;
double jointPosition = 0; // jointPosition = (jointValue1 - min)/divr
double pos1[5];	// pos1 = Weighted average(jointPosition) for the linear motor.
double pos2[5];		// pos2 = position for the servo motors.
std_msgs::Float32MultiArray position; // position = pos1*^ + pos2*^
std_msgs::Int16MultiArray servo;
bool next = false;

double Linear[5];
double Servo[4];
int feedback_recived[5];
int Fsr_recived[6];

// Callback function for the topic '/feedback'
void setMotorfeedback(const std_msgs::Int16MultiArray::ConstPtr& fd_msg){
	if (next)
		return;
	
	feedback_recived[0] = fd_msg->data[0];
	feedback_recived[1] = fd_msg->data[1];
	feedback_recived[2] = fd_msg->data[2];
	feedback_recived[3] = fd_msg->data[3];
	feedback_recived[4] = fd_msg->data[4];
}
void setFsrmsg(const std_msgs::Int16MultiArray::ConstPtr& fsr_msg){
	if (next)
		return;
	
	Fsr_recived[0] = fsr_msg->data[0];
	Fsr_recived[1] = fsr_msg->data[1];
	Fsr_recived[2] = fsr_msg->data[2];
	Fsr_recived[3] = fsr_msg->data[3];
	Fsr_recived[4] = fsr_msg->data[4];
	Fsr_recived[5] = fsr_msg->data[5];
}

void Outputcontroll(){
	//linear motor controled by 2 sets of parameters; servo based on the pos1;
	//remap pos1 to 180~0,(180~105for thumb);
	//servo motor:
	Servo[0] = 180 - (pos1[0]*75); 
	Servo[1] = 180 - (pos1[1]*180);
	Servo[2] = 180 - (pos1[2]*180);
	Servo[3] = 180 - ((pos1[3]+pos1[4])*90);
	
	//linear motor: when the Servo at 180(lose) the max positions for the 
	// 		linear motors are(T->P): 0.56; 0.40; 0.40; 0.40; 0.5.
	double limit[] = {0,0,0,0,0};

	Linear[0] = 1-((pos2[0]*0.44) + (pos1[0]*0.56));
	Linear[1] = 1-((pos2[1]*0.60) + (pos1[1]*0.40));
	Linear[2] = 1-((pos2[2]*0.60) + (pos1[2]*0.40));
	Linear[3] = 1-((pos2[3]*0.60) + (pos1[3]*0.40));
	Linear[4] = 1-((pos2[4]*0.50) + (pos1[4]*0.50));
	
	if (Fsr_recived[0]>800){
		memcpy(limit, Linear, sizeof(Linear));
		for(int i = 0; i < 5; i++){
			Linear[i] = limit[i] +0.02;
		}
	}
	if(Fsr_recived[1]>300){
		Linear[0] += 0.02;
	}
	if(Fsr_recived[2]>300){
		Linear[1] += 0.02;
	}
	if(Fsr_recived[3]>300){
		Linear[2] += 0.02;
	}
	if(Fsr_recived[4]>300){
		Linear[3] += 0.02;
	}
	if(Fsr_recived[5]>300){
		Linear[4] += 0.02;
	}
}

// Callback function for the topic '/cyberglove/raw/joint_states'. This functions give the fairly good parameters of the finger.
void setPositionCb(const sensor_msgs::JointState::ConstPtr& msg) {
	if (next)
		return;

	for(int k=0; k<5; k++){
		pos1[k] = 0;
		pos2[k] = 0;
	}

	// Thumb
	for (int i=0; i<3; i++) { // 2 joints used for the Thumb
		long j = std::find(msg->name.begin(), msg->name.end(), ThumbJ[i]) - msg->name.begin();
		jointValue1 = msg->position[j];

		// Calibration
		if (jointValue1 < minValueThumbJoints[i])
			minValueThumbJoints[i] = jointValue1;
		if (jointValue1*1.001 > maxValueThumbJoints[i])
			maxValueThumbJoints[i] = jointValue1*1.001;

		divr = maxValueThumbJoints[i] - minValueThumbJoints[i];
		// Just to avoid 0/0 in the first iteration
		if (divr == 0)
			divr = 1;

		min = minValueThumbJoints[i] + 0.1*divr;
		max = maxValueThumbJoints[i] - 0.1*divr;

		divr_aux = max - min;

		jointPosition = (jointValue1 - min)/divr_aux;

		// Make sure it's in the range [0;1]
		if (jointPosition > 1)
			jointPosition = 1;
		else
		if (jointPosition < 0)
			jointPosition = 0;

		if (i<2)
			pos1[0]+=(jointPosition * WThumb[i]);
		else
			pos2[0] = (jointPosition);
		
		
	}
	

	// Index
	for (int i=0; i<2; i++) {
		long j = std::find(msg->name.begin(), msg->name.end(), IndexJ[i]) - msg->name.begin();
		jointValue1 = msg->position[j];
		

		// Calibration
		if (jointValue1 < minValueIndexJoints[i])
			minValueIndexJoints[i] = jointValue1;
		if (jointValue1*1.01 > maxValueIndexJoints[i])
			maxValueIndexJoints[i] = jointValue1*1.01;

		divr = maxValueIndexJoints[i] - minValueIndexJoints[i];
		// Just to avoid 0/0 in the first iteration
		if (divr == 0)
			divr = 1;

		min = minValueIndexJoints[i] + 0.1*divr;
		max = maxValueIndexJoints[i] - 0.1*divr;

		divr_aux = max - min;
		jointPosition = (jointValue1 - min)/divr_aux;

		// Make sure it's in the range [0;1]
		if (jointPosition > 1)
			jointPosition = 1;
		else
		if (jointPosition < 0)
			jointPosition = 0;

		if (i==0)
			pos1[1] =(jointPosition);
		else
			pos2[1] = (jointPosition);
	}
	

	// Middle
	for (int i=0; i<2; i++) {
		long j = std::find(msg->name.begin(), msg->name.end(), MiddleJ[i]) - msg->name.begin();
		jointValue1 = msg->position[j];

		// Calibration
		if (jointValue1 < minValueMiddleJoints[i])
			minValueMiddleJoints[i] = jointValue1;
		if (jointValue1*1.01 > maxValueMiddleJoints[i])
			maxValueMiddleJoints[i] = jointValue1*1.01;

		divr = maxValueMiddleJoints[i] - minValueMiddleJoints[i];
		// Just to avoid 0/0 in the first iteration
		if (divr == 0)
			divr = 1;

		min = minValueMiddleJoints[i] + 0.1*divr;
		max = maxValueMiddleJoints[i] - 0.1*divr;

		divr_aux = max - min;

		jointPosition = (jointValue1 - min)/divr_aux;

		// Make sure it's in the range [0;1]
		if (jointPosition > 1)
			jointPosition = 1;
		else
		if (jointPosition < 0)
			jointPosition = 0;

		if (i==0)
			pos1[2] =(jointPosition);
		else
			pos2[2] = (jointPosition);
	}

	// Ring
	for (int i=0; i<2; i++) {
		long j = std::find(msg->name.begin(), msg->name.end(), RingJ[i]) - msg->name.begin();
		jointValue1 = msg->position[j];

		// Calibration
		if (jointValue1 < minValueRingJoints[i])
			minValueRingJoints[i] = jointValue1;
		if (jointValue1*1.01 > maxValueRingJoints[i])
			maxValueRingJoints[i] = jointValue1*1.01;
                                                              
		divr = maxValueRingJoints[i] - minValueRingJoints[i];
		// Just to avoid 0/0 in the first iteration
		if (divr == 0)
			divr = 1;

		min = minValueRingJoints[i] + 0.1*divr;
		max = maxValueRingJoints[i] - 0.1*divr;

		divr_aux = max - min;

		jointPosition = (jointValue1 - min)/divr_aux;

		// Make sure it's in the range [0;1]
		if (jointPosition > 1)
			jointPosition = 1;
		else
		if (jointPosition < 0)
			jointPosition = 0;

		if (i==0)
			pos1[3] =(jointPosition);
		else
			pos2[3] = (jointPosition);
	}

	// Pinkie
	for (int i=0; i<2; i++) {
		long j = std::find(msg->name.begin(), msg->name.end(), PinkieJ[i]) - msg->name.begin();
		jointValue1 = msg->position[j];

		// Calibration
		if (jointValue1 < minValuePinkieJoints[i])
			minValuePinkieJoints[i] = jointValue1;
		if (jointValue1*1.01 > maxValuePinkieJoints[i])
			maxValuePinkieJoints[i] = jointValue1*1.01;

		divr = maxValuePinkieJoints[i] - minValuePinkieJoints[i];
		// Just to avoid 0/0 in the first iteration
		if (divr == 0)
			divr = 1;

		min = minValuePinkieJoints[i] + 0.1*divr;
		max = maxValuePinkieJoints[i] - 0.1*divr;

		divr_aux = max - min;

		jointPosition = (jointValue1 - min)/divr_aux;

		// Make sure it's in the range [0;1]
		if (jointPosition > 1)
			jointPosition = 1;
		else
		if (jointPosition < 0)
			jointPosition = 0;
		if (i==0)
			pos1[4] =(jointPosition);
		else
			pos2[4] = (jointPosition);
	}
	next = true;

	Outputcontroll();
}


int main (int argc, char **argv)
{
	ros::init(argc, argv, "cyberglove_remap");
	ros::NodeHandle nh;

	
	position.data.resize(5); // 5 Fingers 
	servo.data.resize(4);

	ros::Publisher pub1 = nh.advertise<std_msgs::Float32MultiArray>("/position", 32); // Publish the linear position
	ros::Publisher pub2 = nh.advertise<std_msgs::Int16MultiArray>("/servo",32); //publish the servo position.
	
	ros::Subscriber sub1 = nh.subscribe("/cybertouch/raw/joint_states", 32, setPositionCb); // Calculate position from the raw/joint_states' values
	ros::Subscriber sub2 = nh.subscribe<std_msgs::Int16MultiArray>("/feedback",32,setMotorfeedback);
	ros::Subscriber sub3 = nh.subscribe<std_msgs::Int16MultiArray>("/Fsr/sensor_msgs",32,setFsrmsg);

	ROS_INFO("Starting mapping...");
	ROS_INFO("Open and close your hand to calibrate the glove.");	
	
	

	while(ros::ok()) {
		if (next) {
			for(int i=0; i<4; i++){
				servo.data[i] = Servo[i];
			}

			for(int i=0; i<5; i++) {

                position.data[i] = Linear[i];
			}
			pub1.publish(position);	
			pub2.publish(servo);
			
			next = false;
		}
		ros::spinOnce();
	}	
	ros::shutdown();

	ROS_INFO("Bye.");

	return 0;
}


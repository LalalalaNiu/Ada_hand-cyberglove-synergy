
"use strict";

let Test = require('./Test.js')

module.exports = {
  Test: Test,
};

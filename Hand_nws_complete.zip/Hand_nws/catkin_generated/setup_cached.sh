#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export ROS_PACKAGE_PATH="/home/xander/Hand_nws/src:/home/xander/Hand_nws/src/leapnode:/opt/ros/melodic/share"
#ifndef _ROS_th_middle_messages_raw_barometer2_serial_h
#define _ROS_th_middle_messages_raw_barometer2_serial_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "th_messages/raw_barometer2.h"

namespace th_middle_messages
{

  class raw_barometer2_serial : public ros::Msg
  {
    public:
      uint32_t baros2_length;
      typedef th_messages::raw_barometer2 _baros2_type;
      _baros2_type st_baros2;
      _baros2_type * baros2;

    raw_barometer2_serial():
      baros2_length(0), baros2(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->baros2_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->baros2_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->baros2_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->baros2_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->baros2_length);
      for( uint32_t i = 0; i < baros2_length; i++){
      offset += this->baros2[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint32_t baros2_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      baros2_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      baros2_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      baros2_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->baros2_length);
      if(baros2_lengthT > baros2_length)
        this->baros2 = (th_messages::raw_barometer2*)realloc(this->baros2, baros2_lengthT * sizeof(th_messages::raw_barometer2));
      baros2_length = baros2_lengthT;
      for( uint32_t i = 0; i < baros2_length; i++){
      offset += this->st_baros2.deserialize(inbuffer + offset);
        memcpy( &(this->baros2[i]), &(this->st_baros2), sizeof(th_messages::raw_barometer2));
      }
     return offset;
    }

    const char * getType(){ return "th_middle_messages/raw_barometer2_serial"; };
    const char * getMD5(){ return "a32eaeb2fc6574d82d0bca3dd0dc8f6a"; };

  };

}
#endif
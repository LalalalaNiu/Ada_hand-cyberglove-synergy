#ifndef _ROS_th_middle_messages_raw_barometer_serial_h
#define _ROS_th_middle_messages_raw_barometer_serial_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "th_messages/raw_barometer.h"

namespace th_middle_messages
{

  class raw_barometer_serial : public ros::Msg
  {
    public:
      uint32_t baros_length;
      typedef th_messages::raw_barometer _baros_type;
      _baros_type st_baros;
      _baros_type * baros;

    raw_barometer_serial():
      baros_length(0), baros(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->baros_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->baros_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->baros_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->baros_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->baros_length);
      for( uint32_t i = 0; i < baros_length; i++){
      offset += this->baros[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint32_t baros_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      baros_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      baros_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      baros_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->baros_length);
      if(baros_lengthT > baros_length)
        this->baros = (th_messages::raw_barometer*)realloc(this->baros, baros_lengthT * sizeof(th_messages::raw_barometer));
      baros_length = baros_lengthT;
      for( uint32_t i = 0; i < baros_length; i++){
      offset += this->st_baros.deserialize(inbuffer + offset);
        memcpy( &(this->baros[i]), &(this->st_baros), sizeof(th_messages::raw_barometer));
      }
     return offset;
    }

    const char * getType(){ return "th_middle_messages/raw_barometer_serial"; };
    const char * getMD5(){ return "7f630d488162f2fb9ae8cc4e653b1937"; };

  };

}
#endif
#ifndef _ROS_SERVICE_bias_srv_h
#define _ROS_SERVICE_bias_srv_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace th_middle_messages
{

static const char BIAS_SRV[] = "th_middle_messages/bias_srv";

  class bias_srvRequest : public ros::Msg
  {
    public:
      typedef int16_t _num_secs_type;
      _num_secs_type num_secs;

    bias_srvRequest():
      num_secs(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_num_secs;
      u_num_secs.real = this->num_secs;
      *(outbuffer + offset + 0) = (u_num_secs.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_num_secs.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->num_secs);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_num_secs;
      u_num_secs.base = 0;
      u_num_secs.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_num_secs.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->num_secs = u_num_secs.real;
      offset += sizeof(this->num_secs);
     return offset;
    }

    const char * getType(){ return BIAS_SRV; };
    const char * getMD5(){ return "0ca836a613133c666e1004286aa0e937"; };

  };

  class bias_srvResponse : public ros::Msg
  {
    public:
      uint32_t b_ax_length;
      typedef float _b_ax_type;
      _b_ax_type st_b_ax;
      _b_ax_type * b_ax;
      uint32_t b_ay_length;
      typedef float _b_ay_type;
      _b_ay_type st_b_ay;
      _b_ay_type * b_ay;
      uint32_t b_az_length;
      typedef float _b_az_type;
      _b_az_type st_b_az;
      _b_az_type * b_az;
      uint32_t b_gx_length;
      typedef float _b_gx_type;
      _b_gx_type st_b_gx;
      _b_gx_type * b_gx;
      uint32_t b_gy_length;
      typedef float _b_gy_type;
      _b_gy_type st_b_gy;
      _b_gy_type * b_gy;
      uint32_t b_gz_length;
      typedef float _b_gz_type;
      _b_gz_type st_b_gz;
      _b_gz_type * b_gz;

    bias_srvResponse():
      b_ax_length(0), b_ax(NULL),
      b_ay_length(0), b_ay(NULL),
      b_az_length(0), b_az(NULL),
      b_gx_length(0), b_gx(NULL),
      b_gy_length(0), b_gy(NULL),
      b_gz_length(0), b_gz(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->b_ax_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_ax_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_ax_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_ax_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_ax_length);
      for( uint32_t i = 0; i < b_ax_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_axi;
      u_b_axi.real = this->b_ax[i];
      *(outbuffer + offset + 0) = (u_b_axi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_axi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_axi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_axi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_ax[i]);
      }
      *(outbuffer + offset + 0) = (this->b_ay_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_ay_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_ay_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_ay_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_ay_length);
      for( uint32_t i = 0; i < b_ay_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_ayi;
      u_b_ayi.real = this->b_ay[i];
      *(outbuffer + offset + 0) = (u_b_ayi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_ayi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_ayi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_ayi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_ay[i]);
      }
      *(outbuffer + offset + 0) = (this->b_az_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_az_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_az_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_az_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_az_length);
      for( uint32_t i = 0; i < b_az_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_azi;
      u_b_azi.real = this->b_az[i];
      *(outbuffer + offset + 0) = (u_b_azi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_azi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_azi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_azi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_az[i]);
      }
      *(outbuffer + offset + 0) = (this->b_gx_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_gx_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_gx_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_gx_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gx_length);
      for( uint32_t i = 0; i < b_gx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_gxi;
      u_b_gxi.real = this->b_gx[i];
      *(outbuffer + offset + 0) = (u_b_gxi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_gxi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_gxi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_gxi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gx[i]);
      }
      *(outbuffer + offset + 0) = (this->b_gy_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_gy_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_gy_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_gy_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gy_length);
      for( uint32_t i = 0; i < b_gy_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_gyi;
      u_b_gyi.real = this->b_gy[i];
      *(outbuffer + offset + 0) = (u_b_gyi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_gyi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_gyi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_gyi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gy[i]);
      }
      *(outbuffer + offset + 0) = (this->b_gz_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->b_gz_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->b_gz_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->b_gz_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gz_length);
      for( uint32_t i = 0; i < b_gz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_b_gzi;
      u_b_gzi.real = this->b_gz[i];
      *(outbuffer + offset + 0) = (u_b_gzi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_b_gzi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_b_gzi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_b_gzi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->b_gz[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint32_t b_ax_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_ax_length);
      if(b_ax_lengthT > b_ax_length)
        this->b_ax = (float*)realloc(this->b_ax, b_ax_lengthT * sizeof(float));
      b_ax_length = b_ax_lengthT;
      for( uint32_t i = 0; i < b_ax_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_ax;
      u_st_b_ax.base = 0;
      u_st_b_ax.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_ax.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_ax.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_ax.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_ax = u_st_b_ax.real;
      offset += sizeof(this->st_b_ax);
        memcpy( &(this->b_ax[i]), &(this->st_b_ax), sizeof(float));
      }
      uint32_t b_ay_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_ay_length);
      if(b_ay_lengthT > b_ay_length)
        this->b_ay = (float*)realloc(this->b_ay, b_ay_lengthT * sizeof(float));
      b_ay_length = b_ay_lengthT;
      for( uint32_t i = 0; i < b_ay_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_ay;
      u_st_b_ay.base = 0;
      u_st_b_ay.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_ay.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_ay.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_ay.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_ay = u_st_b_ay.real;
      offset += sizeof(this->st_b_ay);
        memcpy( &(this->b_ay[i]), &(this->st_b_ay), sizeof(float));
      }
      uint32_t b_az_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_az_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_az_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_az_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_az_length);
      if(b_az_lengthT > b_az_length)
        this->b_az = (float*)realloc(this->b_az, b_az_lengthT * sizeof(float));
      b_az_length = b_az_lengthT;
      for( uint32_t i = 0; i < b_az_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_az;
      u_st_b_az.base = 0;
      u_st_b_az.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_az.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_az.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_az.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_az = u_st_b_az.real;
      offset += sizeof(this->st_b_az);
        memcpy( &(this->b_az[i]), &(this->st_b_az), sizeof(float));
      }
      uint32_t b_gx_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_gx_length);
      if(b_gx_lengthT > b_gx_length)
        this->b_gx = (float*)realloc(this->b_gx, b_gx_lengthT * sizeof(float));
      b_gx_length = b_gx_lengthT;
      for( uint32_t i = 0; i < b_gx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_gx;
      u_st_b_gx.base = 0;
      u_st_b_gx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_gx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_gx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_gx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_gx = u_st_b_gx.real;
      offset += sizeof(this->st_b_gx);
        memcpy( &(this->b_gx[i]), &(this->st_b_gx), sizeof(float));
      }
      uint32_t b_gy_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_gy_length);
      if(b_gy_lengthT > b_gy_length)
        this->b_gy = (float*)realloc(this->b_gy, b_gy_lengthT * sizeof(float));
      b_gy_length = b_gy_lengthT;
      for( uint32_t i = 0; i < b_gy_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_gy;
      u_st_b_gy.base = 0;
      u_st_b_gy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_gy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_gy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_gy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_gy = u_st_b_gy.real;
      offset += sizeof(this->st_b_gy);
        memcpy( &(this->b_gy[i]), &(this->st_b_gy), sizeof(float));
      }
      uint32_t b_gz_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      b_gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      b_gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      b_gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->b_gz_length);
      if(b_gz_lengthT > b_gz_length)
        this->b_gz = (float*)realloc(this->b_gz, b_gz_lengthT * sizeof(float));
      b_gz_length = b_gz_lengthT;
      for( uint32_t i = 0; i < b_gz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_b_gz;
      u_st_b_gz.base = 0;
      u_st_b_gz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_b_gz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_b_gz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_b_gz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_b_gz = u_st_b_gz.real;
      offset += sizeof(this->st_b_gz);
        memcpy( &(this->b_gz[i]), &(this->st_b_gz), sizeof(float));
      }
     return offset;
    }

    const char * getType(){ return BIAS_SRV; };
    const char * getMD5(){ return "2187bf05b0e439632c97738dad2eae32"; };

  };

  class bias_srv {
    public:
    typedef bias_srvRequest Request;
    typedef bias_srvResponse Response;
  };

}
#endif

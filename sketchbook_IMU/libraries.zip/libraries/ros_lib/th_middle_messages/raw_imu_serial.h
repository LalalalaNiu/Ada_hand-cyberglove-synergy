#ifndef _ROS_th_middle_messages_raw_imu_serial_h
#define _ROS_th_middle_messages_raw_imu_serial_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "th_messages/raw_imu.h"

namespace th_middle_messages
{

  class raw_imu_serial : public ros::Msg
  {
    public:
      uint32_t imus_length;
      typedef th_messages::raw_imu _imus_type;
      _imus_type st_imus;
      _imus_type * imus;

    raw_imu_serial():
      imus_length(0), imus(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->imus_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->imus_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->imus_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->imus_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->imus_length);
      for( uint32_t i = 0; i < imus_length; i++){
      offset += this->imus[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint32_t imus_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      imus_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      imus_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      imus_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->imus_length);
      if(imus_lengthT > imus_length)
        this->imus = (th_messages::raw_imu*)realloc(this->imus, imus_lengthT * sizeof(th_messages::raw_imu));
      imus_length = imus_lengthT;
      for( uint32_t i = 0; i < imus_length; i++){
      offset += this->st_imus.deserialize(inbuffer + offset);
        memcpy( &(this->imus[i]), &(this->st_imus), sizeof(th_messages::raw_imu));
      }
     return offset;
    }

    const char * getType(){ return "th_middle_messages/raw_imu_serial"; };
    const char * getMD5(){ return "bf6b782ad59ebe5fad0f029c0e04fc49"; };

  };

}
#endif
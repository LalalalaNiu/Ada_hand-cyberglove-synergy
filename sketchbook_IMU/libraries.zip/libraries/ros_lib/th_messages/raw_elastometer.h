#ifndef _ROS_th_messages_raw_elastometer_h
#define _ROS_th_messages_raw_elastometer_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace th_messages
{

  class raw_elastometer : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef uint8_t _rows_type;
      _rows_type rows;
      typedef uint8_t _cols_type;
      _cols_type cols;
      uint32_t p_level_length;
      typedef uint32_t _p_level_type;
      _p_level_type st_p_level;
      _p_level_type * p_level;

    raw_elastometer():
      header(),
      rows(0),
      cols(0),
      p_level_length(0), p_level(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->rows >> (8 * 0)) & 0xFF;
      offset += sizeof(this->rows);
      *(outbuffer + offset + 0) = (this->cols >> (8 * 0)) & 0xFF;
      offset += sizeof(this->cols);
      *(outbuffer + offset + 0) = (this->p_level_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->p_level_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->p_level_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->p_level_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->p_level_length);
      for( uint32_t i = 0; i < p_level_length; i++){
      *(outbuffer + offset + 0) = (this->p_level[i] >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->p_level[i] >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->p_level[i] >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->p_level[i] >> (8 * 3)) & 0xFF;
      offset += sizeof(this->p_level[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      this->rows =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->rows);
      this->cols =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->cols);
      uint32_t p_level_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      p_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      p_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      p_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->p_level_length);
      if(p_level_lengthT > p_level_length)
        this->p_level = (uint32_t*)realloc(this->p_level, p_level_lengthT * sizeof(uint32_t));
      p_level_length = p_level_lengthT;
      for( uint32_t i = 0; i < p_level_length; i++){
      this->st_p_level =  ((uint32_t) (*(inbuffer + offset)));
      this->st_p_level |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->st_p_level |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->st_p_level |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->st_p_level);
        memcpy( &(this->p_level[i]), &(this->st_p_level), sizeof(uint32_t));
      }
     return offset;
    }

    const char * getType(){ return "th_messages/raw_elastometer"; };
    const char * getMD5(){ return "a25a3ba9a447cce9b672c660d7b15412"; };

  };

}
#endif
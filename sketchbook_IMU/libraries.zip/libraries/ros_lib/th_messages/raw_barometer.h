#ifndef _ROS_th_messages_raw_barometer_h
#define _ROS_th_messages_raw_barometer_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace th_messages
{

  class raw_barometer : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef int16_t _sensor_id_type;
      _sensor_id_type sensor_id;
      typedef float _tempe_type;
      _tempe_type tempe;
      typedef float _baro_level_type;
      _baro_level_type baro_level;

    raw_barometer():
      header(),
      sensor_id(0),
      tempe(0),
      baro_level(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      union {
        int16_t real;
        uint16_t base;
      } u_sensor_id;
      u_sensor_id.real = this->sensor_id;
      *(outbuffer + offset + 0) = (u_sensor_id.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_sensor_id.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->sensor_id);
      union {
        float real;
        uint32_t base;
      } u_tempe;
      u_tempe.real = this->tempe;
      *(outbuffer + offset + 0) = (u_tempe.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tempe.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tempe.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tempe.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe);
      union {
        float real;
        uint32_t base;
      } u_baro_level;
      u_baro_level.real = this->baro_level;
      *(outbuffer + offset + 0) = (u_baro_level.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_baro_level.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_baro_level.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_baro_level.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->baro_level);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      union {
        int16_t real;
        uint16_t base;
      } u_sensor_id;
      u_sensor_id.base = 0;
      u_sensor_id.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_sensor_id.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->sensor_id = u_sensor_id.real;
      offset += sizeof(this->sensor_id);
      union {
        float real;
        uint32_t base;
      } u_tempe;
      u_tempe.base = 0;
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tempe = u_tempe.real;
      offset += sizeof(this->tempe);
      union {
        float real;
        uint32_t base;
      } u_baro_level;
      u_baro_level.base = 0;
      u_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->baro_level = u_baro_level.real;
      offset += sizeof(this->baro_level);
     return offset;
    }

    const char * getType(){ return "th_messages/raw_barometer"; };
    const char * getMD5(){ return "5f8059946af2eac503e357862e785812"; };

  };

}
#endif
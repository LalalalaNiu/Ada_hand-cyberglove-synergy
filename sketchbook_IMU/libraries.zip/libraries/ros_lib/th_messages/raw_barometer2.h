#ifndef _ROS_th_messages_raw_barometer2_h
#define _ROS_th_messages_raw_barometer2_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace th_messages
{

  class raw_barometer2 : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      uint32_t tempe_length;
      typedef float _tempe_type;
      _tempe_type st_tempe;
      _tempe_type * tempe;
      uint32_t baro_level_length;
      typedef float _baro_level_type;
      _baro_level_type st_baro_level;
      _baro_level_type * baro_level;

    raw_barometer2():
      header(),
      tempe_length(0), tempe(NULL),
      baro_level_length(0), baro_level(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->tempe_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->tempe_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->tempe_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->tempe_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe_length);
      for( uint32_t i = 0; i < tempe_length; i++){
      union {
        float real;
        uint32_t base;
      } u_tempei;
      u_tempei.real = this->tempe[i];
      *(outbuffer + offset + 0) = (u_tempei.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tempei.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tempei.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tempei.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe[i]);
      }
      *(outbuffer + offset + 0) = (this->baro_level_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->baro_level_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->baro_level_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->baro_level_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->baro_level_length);
      for( uint32_t i = 0; i < baro_level_length; i++){
      union {
        float real;
        uint32_t base;
      } u_baro_leveli;
      u_baro_leveli.real = this->baro_level[i];
      *(outbuffer + offset + 0) = (u_baro_leveli.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_baro_leveli.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_baro_leveli.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_baro_leveli.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->baro_level[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      uint32_t tempe_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->tempe_length);
      if(tempe_lengthT > tempe_length)
        this->tempe = (float*)realloc(this->tempe, tempe_lengthT * sizeof(float));
      tempe_length = tempe_lengthT;
      for( uint32_t i = 0; i < tempe_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_tempe;
      u_st_tempe.base = 0;
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_tempe = u_st_tempe.real;
      offset += sizeof(this->st_tempe);
        memcpy( &(this->tempe[i]), &(this->st_tempe), sizeof(float));
      }
      uint32_t baro_level_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      baro_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      baro_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      baro_level_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->baro_level_length);
      if(baro_level_lengthT > baro_level_length)
        this->baro_level = (float*)realloc(this->baro_level, baro_level_lengthT * sizeof(float));
      baro_level_length = baro_level_lengthT;
      for( uint32_t i = 0; i < baro_level_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_baro_level;
      u_st_baro_level.base = 0;
      u_st_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_baro_level.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_baro_level = u_st_baro_level.real;
      offset += sizeof(this->st_baro_level);
        memcpy( &(this->baro_level[i]), &(this->st_baro_level), sizeof(float));
      }
     return offset;
    }

    const char * getType(){ return "th_messages/raw_barometer2"; };
    const char * getMD5(){ return "f076f0fa677fd465f2c44b54f6890c1a"; };

  };

}
#endif
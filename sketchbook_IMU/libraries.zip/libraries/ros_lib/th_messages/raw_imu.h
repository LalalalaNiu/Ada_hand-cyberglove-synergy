#ifndef _ROS_th_messages_raw_imu_h
#define _ROS_th_messages_raw_imu_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace th_messages
{

  class raw_imu : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef int16_t _sensor_id_type;
      _sensor_id_type sensor_id;
      typedef float _tempe_type;
      _tempe_type tempe;
      typedef float _ax_type;
      _ax_type ax;
      typedef float _ay_type;
      _ay_type ay;
      typedef float _az_type;
      _az_type az;
      typedef float _gx_type;
      _gx_type gx;
      typedef float _gy_type;
      _gy_type gy;
      typedef float _gz_type;
      _gz_type gz;
      typedef float _mx_type;
      _mx_type mx;
      typedef float _my_type;
      _my_type my;
      typedef float _mz_type;
      _mz_type mz;

    raw_imu():
      header(),
      sensor_id(0),
      tempe(0),
      ax(0),
      ay(0),
      az(0),
      gx(0),
      gy(0),
      gz(0),
      mx(0),
      my(0),
      mz(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      union {
        int16_t real;
        uint16_t base;
      } u_sensor_id;
      u_sensor_id.real = this->sensor_id;
      *(outbuffer + offset + 0) = (u_sensor_id.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_sensor_id.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->sensor_id);
      union {
        float real;
        uint32_t base;
      } u_tempe;
      u_tempe.real = this->tempe;
      *(outbuffer + offset + 0) = (u_tempe.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tempe.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tempe.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tempe.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe);
      union {
        float real;
        uint32_t base;
      } u_ax;
      u_ax.real = this->ax;
      *(outbuffer + offset + 0) = (u_ax.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ax.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_ax.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_ax.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ax);
      union {
        float real;
        uint32_t base;
      } u_ay;
      u_ay.real = this->ay;
      *(outbuffer + offset + 0) = (u_ay.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ay.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_ay.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_ay.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ay);
      union {
        float real;
        uint32_t base;
      } u_az;
      u_az.real = this->az;
      *(outbuffer + offset + 0) = (u_az.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_az.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_az.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_az.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->az);
      union {
        float real;
        uint32_t base;
      } u_gx;
      u_gx.real = this->gx;
      *(outbuffer + offset + 0) = (u_gx.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gx.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gx.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gx.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gx);
      union {
        float real;
        uint32_t base;
      } u_gy;
      u_gy.real = this->gy;
      *(outbuffer + offset + 0) = (u_gy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gy.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gy.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gy.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gy);
      union {
        float real;
        uint32_t base;
      } u_gz;
      u_gz.real = this->gz;
      *(outbuffer + offset + 0) = (u_gz.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gz.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gz.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gz.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gz);
      union {
        float real;
        uint32_t base;
      } u_mx;
      u_mx.real = this->mx;
      *(outbuffer + offset + 0) = (u_mx.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mx.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_mx.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_mx.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mx);
      union {
        float real;
        uint32_t base;
      } u_my;
      u_my.real = this->my;
      *(outbuffer + offset + 0) = (u_my.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_my.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_my.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_my.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->my);
      union {
        float real;
        uint32_t base;
      } u_mz;
      u_mz.real = this->mz;
      *(outbuffer + offset + 0) = (u_mz.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mz.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_mz.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_mz.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mz);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      union {
        int16_t real;
        uint16_t base;
      } u_sensor_id;
      u_sensor_id.base = 0;
      u_sensor_id.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_sensor_id.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->sensor_id = u_sensor_id.real;
      offset += sizeof(this->sensor_id);
      union {
        float real;
        uint32_t base;
      } u_tempe;
      u_tempe.base = 0;
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tempe.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tempe = u_tempe.real;
      offset += sizeof(this->tempe);
      union {
        float real;
        uint32_t base;
      } u_ax;
      u_ax.base = 0;
      u_ax.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ax.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_ax.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_ax.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->ax = u_ax.real;
      offset += sizeof(this->ax);
      union {
        float real;
        uint32_t base;
      } u_ay;
      u_ay.base = 0;
      u_ay.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_ay.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_ay.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_ay.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->ay = u_ay.real;
      offset += sizeof(this->ay);
      union {
        float real;
        uint32_t base;
      } u_az;
      u_az.base = 0;
      u_az.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_az.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_az.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_az.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->az = u_az.real;
      offset += sizeof(this->az);
      union {
        float real;
        uint32_t base;
      } u_gx;
      u_gx.base = 0;
      u_gx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_gx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_gx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->gx = u_gx.real;
      offset += sizeof(this->gx);
      union {
        float real;
        uint32_t base;
      } u_gy;
      u_gy.base = 0;
      u_gy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_gy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_gy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->gy = u_gy.real;
      offset += sizeof(this->gy);
      union {
        float real;
        uint32_t base;
      } u_gz;
      u_gz.base = 0;
      u_gz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_gz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_gz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_gz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->gz = u_gz.real;
      offset += sizeof(this->gz);
      union {
        float real;
        uint32_t base;
      } u_mx;
      u_mx.base = 0;
      u_mx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_mx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_mx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_mx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->mx = u_mx.real;
      offset += sizeof(this->mx);
      union {
        float real;
        uint32_t base;
      } u_my;
      u_my.base = 0;
      u_my.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_my.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_my.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_my.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->my = u_my.real;
      offset += sizeof(this->my);
      union {
        float real;
        uint32_t base;
      } u_mz;
      u_mz.base = 0;
      u_mz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_mz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_mz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_mz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->mz = u_mz.real;
      offset += sizeof(this->mz);
     return offset;
    }

    const char * getType(){ return "th_messages/raw_imu"; };
    const char * getMD5(){ return "51eb1d8b736b5695bb58dc3c4b5e4c55"; };

  };

}
#endif
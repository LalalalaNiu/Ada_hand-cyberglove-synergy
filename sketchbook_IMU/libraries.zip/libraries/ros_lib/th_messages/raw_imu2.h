#ifndef _ROS_th_messages_raw_imu2_h
#define _ROS_th_messages_raw_imu2_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace th_messages
{

  class raw_imu2 : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      uint32_t tempe_length;
      typedef float _tempe_type;
      _tempe_type st_tempe;
      _tempe_type * tempe;
      uint32_t ax_length;
      typedef float _ax_type;
      _ax_type st_ax;
      _ax_type * ax;
      uint32_t ay_length;
      typedef float _ay_type;
      _ay_type st_ay;
      _ay_type * ay;
      uint32_t az_length;
      typedef float _az_type;
      _az_type st_az;
      _az_type * az;
      uint32_t gx_length;
      typedef float _gx_type;
      _gx_type st_gx;
      _gx_type * gx;
      uint32_t gy_length;
      typedef float _gy_type;
      _gy_type st_gy;
      _gy_type * gy;
      uint32_t gz_length;
      typedef float _gz_type;
      _gz_type st_gz;
      _gz_type * gz;
      uint32_t mx_length;
      typedef float _mx_type;
      _mx_type st_mx;
      _mx_type * mx;
      uint32_t my_length;
      typedef float _my_type;
      _my_type st_my;
      _my_type * my;
      uint32_t mz_length;
      typedef float _mz_type;
      _mz_type st_mz;
      _mz_type * mz;

    raw_imu2():
      header(),
      tempe_length(0), tempe(NULL),
      ax_length(0), ax(NULL),
      ay_length(0), ay(NULL),
      az_length(0), az(NULL),
      gx_length(0), gx(NULL),
      gy_length(0), gy(NULL),
      gz_length(0), gz(NULL),
      mx_length(0), mx(NULL),
      my_length(0), my(NULL),
      mz_length(0), mz(NULL)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      *(outbuffer + offset + 0) = (this->tempe_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->tempe_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->tempe_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->tempe_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe_length);
      for( uint32_t i = 0; i < tempe_length; i++){
      union {
        float real;
        uint32_t base;
      } u_tempei;
      u_tempei.real = this->tempe[i];
      *(outbuffer + offset + 0) = (u_tempei.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tempei.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tempei.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tempei.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tempe[i]);
      }
      *(outbuffer + offset + 0) = (this->ax_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->ax_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->ax_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->ax_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ax_length);
      for( uint32_t i = 0; i < ax_length; i++){
      union {
        float real;
        uint32_t base;
      } u_axi;
      u_axi.real = this->ax[i];
      *(outbuffer + offset + 0) = (u_axi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_axi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_axi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_axi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ax[i]);
      }
      *(outbuffer + offset + 0) = (this->ay_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->ay_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->ay_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->ay_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ay_length);
      for( uint32_t i = 0; i < ay_length; i++){
      union {
        float real;
        uint32_t base;
      } u_ayi;
      u_ayi.real = this->ay[i];
      *(outbuffer + offset + 0) = (u_ayi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_ayi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_ayi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_ayi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->ay[i]);
      }
      *(outbuffer + offset + 0) = (this->az_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->az_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->az_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->az_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->az_length);
      for( uint32_t i = 0; i < az_length; i++){
      union {
        float real;
        uint32_t base;
      } u_azi;
      u_azi.real = this->az[i];
      *(outbuffer + offset + 0) = (u_azi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_azi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_azi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_azi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->az[i]);
      }
      *(outbuffer + offset + 0) = (this->gx_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->gx_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->gx_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->gx_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gx_length);
      for( uint32_t i = 0; i < gx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_gxi;
      u_gxi.real = this->gx[i];
      *(outbuffer + offset + 0) = (u_gxi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gxi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gxi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gxi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gx[i]);
      }
      *(outbuffer + offset + 0) = (this->gy_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->gy_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->gy_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->gy_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gy_length);
      for( uint32_t i = 0; i < gy_length; i++){
      union {
        float real;
        uint32_t base;
      } u_gyi;
      u_gyi.real = this->gy[i];
      *(outbuffer + offset + 0) = (u_gyi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gyi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gyi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gyi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gy[i]);
      }
      *(outbuffer + offset + 0) = (this->gz_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->gz_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->gz_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->gz_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gz_length);
      for( uint32_t i = 0; i < gz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_gzi;
      u_gzi.real = this->gz[i];
      *(outbuffer + offset + 0) = (u_gzi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_gzi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_gzi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_gzi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->gz[i]);
      }
      *(outbuffer + offset + 0) = (this->mx_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->mx_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->mx_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->mx_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mx_length);
      for( uint32_t i = 0; i < mx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_mxi;
      u_mxi.real = this->mx[i];
      *(outbuffer + offset + 0) = (u_mxi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mxi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_mxi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_mxi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mx[i]);
      }
      *(outbuffer + offset + 0) = (this->my_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->my_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->my_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->my_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->my_length);
      for( uint32_t i = 0; i < my_length; i++){
      union {
        float real;
        uint32_t base;
      } u_myi;
      u_myi.real = this->my[i];
      *(outbuffer + offset + 0) = (u_myi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_myi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_myi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_myi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->my[i]);
      }
      *(outbuffer + offset + 0) = (this->mz_length >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->mz_length >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->mz_length >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->mz_length >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mz_length);
      for( uint32_t i = 0; i < mz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_mzi;
      u_mzi.real = this->mz[i];
      *(outbuffer + offset + 0) = (u_mzi.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mzi.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_mzi.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_mzi.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->mz[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      uint32_t tempe_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      tempe_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->tempe_length);
      if(tempe_lengthT > tempe_length)
        this->tempe = (float*)realloc(this->tempe, tempe_lengthT * sizeof(float));
      tempe_length = tempe_lengthT;
      for( uint32_t i = 0; i < tempe_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_tempe;
      u_st_tempe.base = 0;
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_tempe.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_tempe = u_st_tempe.real;
      offset += sizeof(this->st_tempe);
        memcpy( &(this->tempe[i]), &(this->st_tempe), sizeof(float));
      }
      uint32_t ax_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      ax_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->ax_length);
      if(ax_lengthT > ax_length)
        this->ax = (float*)realloc(this->ax, ax_lengthT * sizeof(float));
      ax_length = ax_lengthT;
      for( uint32_t i = 0; i < ax_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_ax;
      u_st_ax.base = 0;
      u_st_ax.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_ax.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_ax.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_ax.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_ax = u_st_ax.real;
      offset += sizeof(this->st_ax);
        memcpy( &(this->ax[i]), &(this->st_ax), sizeof(float));
      }
      uint32_t ay_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      ay_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->ay_length);
      if(ay_lengthT > ay_length)
        this->ay = (float*)realloc(this->ay, ay_lengthT * sizeof(float));
      ay_length = ay_lengthT;
      for( uint32_t i = 0; i < ay_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_ay;
      u_st_ay.base = 0;
      u_st_ay.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_ay.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_ay.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_ay.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_ay = u_st_ay.real;
      offset += sizeof(this->st_ay);
        memcpy( &(this->ay[i]), &(this->st_ay), sizeof(float));
      }
      uint32_t az_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      az_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      az_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      az_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->az_length);
      if(az_lengthT > az_length)
        this->az = (float*)realloc(this->az, az_lengthT * sizeof(float));
      az_length = az_lengthT;
      for( uint32_t i = 0; i < az_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_az;
      u_st_az.base = 0;
      u_st_az.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_az.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_az.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_az.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_az = u_st_az.real;
      offset += sizeof(this->st_az);
        memcpy( &(this->az[i]), &(this->st_az), sizeof(float));
      }
      uint32_t gx_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      gx_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->gx_length);
      if(gx_lengthT > gx_length)
        this->gx = (float*)realloc(this->gx, gx_lengthT * sizeof(float));
      gx_length = gx_lengthT;
      for( uint32_t i = 0; i < gx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_gx;
      u_st_gx.base = 0;
      u_st_gx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_gx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_gx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_gx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_gx = u_st_gx.real;
      offset += sizeof(this->st_gx);
        memcpy( &(this->gx[i]), &(this->st_gx), sizeof(float));
      }
      uint32_t gy_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      gy_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->gy_length);
      if(gy_lengthT > gy_length)
        this->gy = (float*)realloc(this->gy, gy_lengthT * sizeof(float));
      gy_length = gy_lengthT;
      for( uint32_t i = 0; i < gy_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_gy;
      u_st_gy.base = 0;
      u_st_gy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_gy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_gy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_gy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_gy = u_st_gy.real;
      offset += sizeof(this->st_gy);
        memcpy( &(this->gy[i]), &(this->st_gy), sizeof(float));
      }
      uint32_t gz_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      gz_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->gz_length);
      if(gz_lengthT > gz_length)
        this->gz = (float*)realloc(this->gz, gz_lengthT * sizeof(float));
      gz_length = gz_lengthT;
      for( uint32_t i = 0; i < gz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_gz;
      u_st_gz.base = 0;
      u_st_gz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_gz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_gz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_gz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_gz = u_st_gz.real;
      offset += sizeof(this->st_gz);
        memcpy( &(this->gz[i]), &(this->st_gz), sizeof(float));
      }
      uint32_t mx_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      mx_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      mx_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      mx_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->mx_length);
      if(mx_lengthT > mx_length)
        this->mx = (float*)realloc(this->mx, mx_lengthT * sizeof(float));
      mx_length = mx_lengthT;
      for( uint32_t i = 0; i < mx_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_mx;
      u_st_mx.base = 0;
      u_st_mx.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_mx.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_mx.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_mx.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_mx = u_st_mx.real;
      offset += sizeof(this->st_mx);
        memcpy( &(this->mx[i]), &(this->st_mx), sizeof(float));
      }
      uint32_t my_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      my_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      my_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      my_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->my_length);
      if(my_lengthT > my_length)
        this->my = (float*)realloc(this->my, my_lengthT * sizeof(float));
      my_length = my_lengthT;
      for( uint32_t i = 0; i < my_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_my;
      u_st_my.base = 0;
      u_st_my.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_my.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_my.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_my.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_my = u_st_my.real;
      offset += sizeof(this->st_my);
        memcpy( &(this->my[i]), &(this->st_my), sizeof(float));
      }
      uint32_t mz_lengthT = ((uint32_t) (*(inbuffer + offset))); 
      mz_lengthT |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1); 
      mz_lengthT |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2); 
      mz_lengthT |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3); 
      offset += sizeof(this->mz_length);
      if(mz_lengthT > mz_length)
        this->mz = (float*)realloc(this->mz, mz_lengthT * sizeof(float));
      mz_length = mz_lengthT;
      for( uint32_t i = 0; i < mz_length; i++){
      union {
        float real;
        uint32_t base;
      } u_st_mz;
      u_st_mz.base = 0;
      u_st_mz.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_st_mz.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_st_mz.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_st_mz.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->st_mz = u_st_mz.real;
      offset += sizeof(this->st_mz);
        memcpy( &(this->mz[i]), &(this->st_mz), sizeof(float));
      }
     return offset;
    }

    const char * getType(){ return "th_messages/raw_imu2"; };
    const char * getMD5(){ return "7fea683002c52f4a1ffae2fd1a0e778f"; };

  };

}
#endif